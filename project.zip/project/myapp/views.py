from django.shortcuts import render,get_object_or_404,render_to_response
from django.shortcuts import redirect
from django.http import HttpResponseRedirect
from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.models import User
from django.contrib.sessions.models import Session
from django.template import RequestContext 
from models import Data,Signup
from .forms import *



# def login(request):
# 	form = loginform()
# 	context = {
# 	"form": form 
# 	}
# 	return render(request,'login.html',context)

# def signup(request):
# 	form = signupform()
# 	context = {
# 	"form": form
# 	}
# 	return render(request,'signup.html',context)


def add_contact(request):
	# session_id = request.session_key
	# session = Session.objects.get(session_key=session_id)
	# session_data = session.get_decoded()
	# uid = session_data.get('_auth_user_id')
	
	if request.method=='POST':
		form=insertform(request.POST)
		if form.is_valid():
			fname = request.POST.get('fname')
			lname = request.POST.get('lname')
			phone_no = request.POST.get('phone_no')
			add = request.POST.get('add')

			userid = usr
			insert_obj=Data(fname=fname,lname=lname,phone_no=phone_no,add=add,userid=userid)
			insert_obj.save()
			return redirect('/retrive/')
	else:
		form=insertform()		
	return render(request,'add_contact.html',{'form': form})

def retrive(request):
	userid = usr
	ret = Data.objects.filter(userid=userid)
	return render(request,'retrive.html',{'data':ret})


def update_contact(request):
	id = eval("request." + request.method + "['id']")
	post = Data.objects.get(id=id)
	if request.method == 'POST':
		form = insertform(request.POST)
		if form.is_valid():
			post.fname = request.POST.get('fname')
			post.lname = request.POST.get('lname')
			post.phone_no = request.POST.get('phone_no')
			post.add = request.POST.get('add')
			post.save()
		return redirect('/retrive/')
	elif request.method == 'GET':
		template = 'update_contact.html'
		params = {'post':post}
	return render(request,template,params)

def delete_contact(request):
	id = eval("request." + request.method + "['id']")
	if request.method == 'POST':
		post = Data.objects(id=id)
		post.delete()
		return redirect('/retrive/')
	elif request.method == 'GET':
		template = 'delete_contact.html'
		params = { 'id': id }
	return render(request,template,params)

def signup(request):
	if request.method =='POST':
		form = signupform(request.POST)
		if form.is_valid():
			user = User.objects.create_user(username = form.cleaned_data['username'],password = form.cleaned_data['password'])
			firstname = request.POST.get('firstname')
			lastname = request.POST.get('lastname')
			username = request.POST.get('username')
			email = request.POST.get('email')
			password = request.POST.get('password')
			signup_obj =Signup(firstname = firstname,lastname = lastname,username = username,email = email,password = password)
			signup_obj.save()
			return redirect('/login/')
	else:
		form = signupform()
	return render(request,'signup.html',{'form':form})


def user_login(request):
	
	if request.method=="POST":
		form = loginform(request.POST)
		if form.is_valid():
			username = form.cleaned_data['username']
			password = form.cleaned_data['password']
			user = authenticate(username = username,password = password)
			if user is not None:
				global usr
				login(request,user)	
				usr = request.user.username

				
			return redirect('/welcome/')
	else:
		form = loginform()
	return render(request,'login.html',{'form':form})


def user_logout(request):
	logout(request)
	return redirect('/home/')

def home(request):
	return render(request,'home.html')

def welcome(request):
	return render(request,'welcome.html')

