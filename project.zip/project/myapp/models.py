from django.db import models
from mongoengine import *


# class Contact(Document):
# 	fname = StringField(max_length=50,required=True)
# 	lname = StringField(max_length=50,required=True)
# 	phone_no = StringField(max_length=10,required=True)
# 	add = StringField(max_length=500,required=True)

class Data(Document):
	fname = StringField(max_length=50,required=True)
	lname = StringField(max_length=50,required=True)
	phone_no = StringField(max_length=10,required=True)
	add = StringField(max_length=500,required=True)
	userid=StringField()

class Signup(Document):
	firstname = StringField(max_length=50,required=True)
	lastname = StringField(max_length=50,required=True)
	username = StringField(max_length=50,required=True)
	email = StringField(max_length=50,required=True)
	password = StringField(max_length=50,required=True)




