from django import forms
import re
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from django.core.exceptions import ObjectDoesNotExist

class loginform(forms.Form):
	
	username = forms.CharField(label='USER_NAME',max_length=30)
	password = forms.CharField(label='PASSWORD',widget=forms.PasswordInput())

	def clean(self):
		username = self.cleaned_data['username']
		password = self.cleaned_data['password']
		user = authenticate(username=username,password=password)
		if not user:
			self.add_error("username","username or password did not match..!!")


class signupform(forms.Form):
	firstname = forms.CharField(label='First_Name',max_length=50)
	lastname = forms.CharField(label='Last_Name',max_length=50)
	username = forms.CharField(label='User_Name',max_length=30)
	email = forms.EmailField(label='Email_ID',required=True)
	password = forms.CharField(label='Password',widget=forms.PasswordInput())
	repassword = forms.CharField(label='Re_Enter_Password',widget=forms.PasswordInput())



	def clean_repassword(self):
		password = self.cleaned_data['password']
		repassword = self.cleaned_data['repassword']
		print password
		print repassword
		if password != repassword:
			raise forms.ValidationError("Password does'nt match...!!")
		else:
			return repassword
	def clear_username(self):
		username = self.cleaned_data['username']
		if not re.search(r'^\w+$', username):
			raise forms.ValidationError("Username can only contain""alphanumeric characters and the underscore.")
		try:
			user = User.objects.get(username=username)
		except ObjectDoesNotExist:
			return username
		raise forms.ValidationError("That user is already taken , please select another ")
		


class insertform(forms.Form):
	fname = forms.CharField(label='First_Name',max_length=50,required = True)
	lname = forms.CharField(label='Last_Name',max_length=50,required = True)
	phone_no = forms.CharField(label='Phone_No',max_length=10,required = True)
	add = forms.CharField(label='Address',max_length=50,required = True)
